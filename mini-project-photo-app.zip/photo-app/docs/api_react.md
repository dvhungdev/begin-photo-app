# Use axios

## Bài 1 sử dụng các thư viện
cmd:
npm i axios
npm i query-string
npm i firebase
npm i react-firebaseui