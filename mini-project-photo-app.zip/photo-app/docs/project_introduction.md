## Bài 1
✅ Các bước setup redux project
✅ Chia sẻ cách tổ chức files thế nào cho hiệu quả (Feature)
✅ Setup routing theo features như thế nào?

## Bài 2:
✅ Hướng dẫn code UI cho phần header và banner
✅ Khi nào dùng Link, khi nào dùng thẻ a?
✅ Sử dụng Google Fonts
✅ Tạo component Banner với default background image
✅ Có nên tách form ra một component riêng không?
✅ Làm giao diện form bao nhanh với reactstrap 🚀
✅ Sử dụng react-select để tạo dropdown xịn xò 😍

## Bài 3:
✅ Vấn đề với relative imports nhiều cấp độ.
✅ Giới thiệu về jsconfig
✅ Sử dụng baseUrl để giải quyết vấn đề về relative imports

## Bài 4
Cách sử dụng Formik để dùng Form
✅ Giới thiệu về cách sử dụng Formik
✅ Gắn Formik vào form hiện tại của mình
✅ Sử dụng custom component cho Formik Field

## Bài 5
Bind custom control vào Formik:
✅ Nhắc lại custom field từ video trước 
✅ Nên dùng UI control có sẵn hay tự viết?
✅ Viết custom control cần lưu ý điều gì?
✅ Bind custom control với Formik như thế nào? 🙂

## Bài 6
✅ Giới thiệu Yup, thư viện javascript giúp mình làm form validation.
✅ Setup form validation với Yup
✅ Field này required khi field kia có giá trị nào đó? Setup thế nào ?

## Bài 10: Deploy ReactJS App lên surge.sh 🚀
✅ Các công ty lớn thường có team handle việc deploy.
✅ Với công ty nhỏ hoặc project nhỏ thì có thể mình sẽ tự handle việc deploy.
✅ Bài hướng dẫn deploy này phù hợp cho các bạn làm project để học, làm bài tập, đồ án, ... Cần sự đơn giản và nhanh chóng.
✅ Deploy lên surge và vấn đề client side routing, khiến bạn bị dính NotFound. Cách giải quyết ra sau.
✅ Viết script auto deploy lên surge 😉 

cmd:
npm i -g surge
