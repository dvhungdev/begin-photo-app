## GIT
$ git checkout -b feature/feature-1 develop : Tạo 1 nhánh mới từ một nhánh đã có


alt + shift + o : Tối ưu code